#include<stdio.h>

void main()
{
   FILE *fp;
   char text[]="yes";
   struct emp
   {
        char name[40];
        int age;
         float bs;
    };
    struct emp e;

    fp=fopen("employee.txt","w");

     if(fp==NULL)
     {
         puts("cannot open the file");
         exit(0);
      }

    // fprintf(fp,"Name \t\t Age \t\t salary\n \n\n ",e.name,e.age,e.bs);
    while(!strcmp(text,"yes"))
    {
       printf("enter name, age, basic salary");
       scanf("%s%d%f",e.name,&e.age,&e.bs);
       fprintf(fp,"%s \t %d \t %f\n \n\n ",e.name,e.age,e.bs);

      printf("enter another record \n");
      scanf("%s",text);

    }
  printf(" Data has been recoreded to file \n");
   fclose(fp);
}
