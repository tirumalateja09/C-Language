#include <stdio.h>
#include <string.h>


void main()
{
    char str[100];
    int i=0, wrd=0,c=0;
	
      	
       printf("Input the string:");
       fgets(str, sizeof str, stdin);	
	
    
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]==' ' || str[i]=='\n' || str[i]=='\t')
        {
            wrd++;
        }

            }

    printf("Total number of words in the string is:%d\n",wrd);
	printf("characters%d",i);
}
