#include<stdio.h>
void main()
{
char ch[8]={'N','a','g','a','m','a','n','i'};
printf("%s\n%c\n",ch,ch[4]);
char a[]="EEE class";
printf("%s\n",a);
char b[30];
printf("enter your name");

scanf("%[^\n]s",b);

printf("%s\n",b);
}
