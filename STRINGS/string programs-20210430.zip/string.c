#include<stdio.h>
#include<string.h>
#include<ctype.h>
void main()
{
int len;
char str1[20],str2[30],str3[40];
printf("\n Enter the string1 ");
scanf("%s",str1);
printf("string1 is :%s\n",str1);
printf("\n Enter the string2 ");
scanf("%s",str2);
printf("string2 is :%s\n",str2);
printf("Enter the string 3 \n");
scanf("%s",str3);
printf("string3 is :%s\n",str3);
len=strlen(str1);
printf("string1 length:%d\n",len);
printf("concat str1 and str2:%s\n",strcat(str1,str2));
printf("comparison of str1 and str2 :%d\n",strcmp(str1,str2));
printf("copy str2 into str1 :%s\n",strcpy(str1,str2));
printf("substring:%s\n",strstr(str1,str3));
for(int i=0;i<strlen(str1);i++)
{
str1[i]=toupper(str1[i]);
}
printf("str1 uppercase:%s\n",str1);


}

