#include <stdio.h>

void main()

{

    char str[80];

    int i, vowels = 0, consonants = 0;
 

    printf("Enter a string \n");

    scanf("%s",str);

    for (i = 0; str[i] != '\0'; i++)

    {


        if ((str[i] == 'a' || str[i] == 'e' || str[i] ==

        'i' || str[i] == 'o' || str[i] == 'u') ||

        (str[i] == 'A' || str[i] == 'E' || str[i] ==

        'I' || str[i] == 'O' || str[i] == 'U'))

        {

            vowels = vowels + 1;

        }

        else

        {

            consonants = consonants + 1;

        }
}
            printf("No. of vowels in %s = %d\n", str, vowels);
            

    printf("No. of consonants in %s = %d\n", str, consonants);

}

